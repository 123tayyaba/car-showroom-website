var a = prompt("Enter a word that has first and last two alphabets same");
a.endsWith(ed)